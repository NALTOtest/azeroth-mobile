# Emberfall Survivors (Android)

An original 3D survivors-style game built for phones: 9 classes, 4 skills each. Uses three.js (MIT license) bundled offline. The game is `app/src/main/assets/index.html`
and runs fully offline inside the app.

Controls: drag anywhere to move, attacks are automatic, tap a card to pick an upgrade.
Back button: pause / resume. From the hero menu, Back exits.
