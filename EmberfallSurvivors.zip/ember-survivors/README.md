# Emberfall Survivors (Android)

An original survivors-style game built for phones. The game is `app/src/main/assets/index.html`
and runs fully offline inside the app.

Controls: drag anywhere to move, attacks are automatic, tap a card to pick an upgrade.
Back button: pause / resume. From the hero menu, Back exits.
