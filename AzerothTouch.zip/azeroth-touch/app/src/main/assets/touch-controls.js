/* Touch controls overlay for keyboard-only browser games.
 * Drag anywhere = virtual joystick (sends WASD / arrow key events).
 * Quick taps pass straight through to the game, so menus and upgrade cards still work.
 * Buttons on the right send Esc / Enter / Space. */
(function () {
  if (window.__touchPad) return;

  var MODES = ['WASD', 'ARROWS', 'BOTH'];
  var KEYS = {
    WASD:   { up: ['w', 'KeyW', 87], down: ['s', 'KeyS', 83], left: ['a', 'KeyA', 65], right: ['d', 'KeyD', 68] },
    ARROWS: { up: ['ArrowUp', 'ArrowUp', 38], down: ['ArrowDown', 'ArrowDown', 40], left: ['ArrowLeft', 'ArrowLeft', 37], right: ['ArrowRight', 'ArrowRight', 39] }
  };
  var SPECIAL = {
    Escape: ['Escape', 'Escape', 27],
    Enter:  ['Enter', 'Enter', 13],
    Space:  [' ', 'Space', 32],
    '1': ['1', 'Digit1', 49],
    '2': ['2', 'Digit2', 50],
    '3': ['3', 'Digit3', 51],
    R:   ['r', 'KeyR', 82]
  };

  var mode = 'WASD';
  try { mode = localStorage.getItem('__touchPadMode') || 'WASD'; } catch (e) {}
  if (MODES.indexOf(mode) < 0) mode = 'WASD';

  var DRAG_START = 14;   // px a finger must move before it becomes a joystick
  var DEADZONE = 0.28;   // fraction of radius
  var RADIUS = 60;

  /* ---------- key event plumbing ---------- */
  function targets() {
    var list = [];
    var c = document.querySelector('canvas');
    list.push({ doc: document, el: c || document.activeElement || document.body });
    // also reach same-origin iframes (cross-origin ones are blocked by the browser)
    var frames = document.querySelectorAll('iframe');
    for (var i = 0; i < frames.length; i++) {
      try {
        var d = frames[i].contentDocument;
        if (d && d.body) list.push({ doc: d, el: d.querySelector('canvas') || d.activeElement || d.body });
      } catch (e) {}
    }
    return list;
  }

  function fire(type, def) {
    var t = targets();
    for (var i = 0; i < t.length; i++) {
      var view = t[i].doc.defaultView || window;
      var ev = new view.KeyboardEvent(type, { key: def[0], code: def[1], bubbles: true, cancelable: true, composed: true });
      try {
        Object.defineProperty(ev, 'keyCode', { get: function () { return def[2]; } });
        Object.defineProperty(ev, 'which', { get: function () { return def[2]; } });
      } catch (e) {}
      t[i].el.dispatchEvent(ev);
    }
  }

  var held = {}; // code -> def
  function setHeld(wanted) {
    var code;
    for (code in held) if (!wanted[code]) { fire('keyup', held[code]); delete held[code]; }
    for (code in wanted) if (!held[code]) { held[code] = wanted[code]; fire('keydown', wanted[code]); }
  }
  function releaseAll() { setHeld({}); }

  function dirKeys(dirs) {
    var out = {};
    var sets = mode === 'BOTH' ? [KEYS.WASD, KEYS.ARROWS] : [KEYS[mode]];
    dirs.forEach(function (d) {
      sets.forEach(function (s) { out[s[d][1]] = s[d]; });
    });
    return out;
  }

  function tap(name) {
    var def = SPECIAL[name];
    if (!def) return;
    fire('keydown', def);
    setTimeout(function () { fire('keyup', def); }, 60);
  }

  /* ---------- UI ---------- */
  var css = document.createElement('style');
  css.textContent =
    'html,body,canvas{touch-action:none!important;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}' +
    '#tp-stick{position:fixed;width:' + RADIUS * 2 + 'px;height:' + RADIUS * 2 + 'px;margin:-' + RADIUS + 'px 0 0 -' + RADIUS + 'px;border-radius:50%;' +
      'background:rgba(255,255,255,.08);border:2px solid rgba(255,255,255,.35);pointer-events:none;z-index:2147483646;display:none}' +
    '#tp-knob{position:absolute;left:50%;top:50%;width:52px;height:52px;margin:-26px 0 0 -26px;border-radius:50%;background:rgba(255,255,255,.45)}' +
    '#tp-btns{position:fixed;right:max(12px,env(safe-area-inset-right));top:max(10px,env(safe-area-inset-top));display:flex;gap:8px;z-index:2147483647}' +
    '#tp-btns button{font:600 12px/1 system-ui,sans-serif;color:#fff;background:rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.35);' +
      'border-radius:10px;padding:10px 12px;min-width:44px;min-height:40px;touch-action:none}' +
    '#tp-btns button:active{background:rgba(255,255,255,.3)}' +
    '#tp-btns.tp-hidden button:not(#tp-toggle){display:none}';
  (document.head || document.documentElement).appendChild(css);

  var stick = document.createElement('div');
  stick.id = 'tp-stick';
  var knob = document.createElement('div');
  knob.id = 'tp-knob';
  stick.appendChild(knob);

  var bar = document.createElement('div');
  bar.id = 'tp-btns';
  function btn(label, fn, id) {
    var b = document.createElement('button');
    b.textContent = label;
    if (id) b.id = id;
    b.addEventListener('touchstart', function (e) { e.preventDefault(); e.stopPropagation(); fn(b); }, { passive: false });
    b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); });
    bar.appendChild(b);
    return b;
  }
  btn('⏸ Esc', function () { tap('Escape'); });
  btn('Enter', function () { tap('Enter'); });
  btn('1', function () { tap('1'); });
  btn('2', function () { tap('2'); });
  btn('3', function () { tap('3'); });
  btn('↻ R', function () { tap('R'); });
  btn('⌨ ' + mode, function (b) {
    releaseAll();
    mode = MODES[(MODES.indexOf(mode) + 1) % MODES.length];
    try { localStorage.setItem('__touchPadMode', mode); } catch (e) {}
    b.textContent = '⌨ ' + mode;
  });
  btn('◐', function () { bar.classList.toggle('tp-hidden'); }, 'tp-toggle');

  function mount() {
    document.body.appendChild(stick);
    document.body.appendChild(bar);
  }

  /* ---------- joystick ---------- */
  var active = null; // {id, x0, y0, live}

  function onStart(e) {
    if (active || bar.contains(e.target)) return;
    var t = e.changedTouches[0];
    active = { id: t.identifier, x0: t.clientX, y0: t.clientY, live: false };
  }

  function onMove(e) {
    if (!active) return;
    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i];
      if (t.identifier !== active.id) continue;
      var dx = t.clientX - active.x0, dy = t.clientY - active.y0;
      var dist = Math.sqrt(dx * dx + dy * dy);
      if (!active.live) {
        if (dist < DRAG_START) return;
        active.live = true;
        stick.style.left = active.x0 + 'px';
        stick.style.top = active.y0 + 'px';
        stick.style.display = 'block';
      }
      if (e.cancelable) e.preventDefault();
      var k = Math.min(dist, RADIUS);
      var nx = dist ? dx / dist : 0, ny = dist ? dy / dist : 0;
      knob.style.transform = 'translate(' + nx * k + 'px,' + ny * k + 'px)';
      var dirs = [];
      if (dist > RADIUS * DEADZONE) {
        // 8-way: a direction counts if it is within ~67.5deg of the stick angle
        if (ny < -0.38) dirs.push('up');
        if (ny > 0.38) dirs.push('down');
        if (nx < -0.38) dirs.push('left');
        if (nx > 0.38) dirs.push('right');
      }
      setHeld(dirKeys(dirs));
    }
  }

  function onEnd(e) {
    if (!active) return;
    for (var i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier !== active.id) continue;
      if (active.live && e.cancelable) e.preventDefault(); // swallow the click a drag would otherwise make
      active = null;
      stick.style.display = 'none';
      knob.style.transform = '';
      releaseAll();
    }
  }

  window.addEventListener('touchstart', onStart, { capture: true, passive: true });
  window.addEventListener('touchmove', onMove, { capture: true, passive: false });
  window.addEventListener('touchend', onEnd, { capture: true, passive: false });
  window.addEventListener('touchcancel', onEnd, { capture: true, passive: false });
  window.addEventListener('blur', releaseAll);
  document.addEventListener('visibilitychange', function () { if (document.hidden) releaseAll(); });

  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);

  window.__touchPad = { tap: tap, releaseAll: releaseAll };
})();
