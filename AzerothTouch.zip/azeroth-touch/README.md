# Azeroth Touch

Touchscreen controls for the original Azeroth Survivors by Aethus. The app loads
https://wow.aethus.pl/ live; nothing from the game is copied into the app.

## Controls
- **Drag anywhere** → virtual joystick (8-way movement)
- **Quick tap** → passes straight through to the game (menus, upgrade cards)
- **Buttons, top right:** ⏸ Esc (pause), Enter (start a run), 1 / 2 / 3 (pick a level-up card), ↻ R (reroll)
- **⌨ WASD** button cycles WASD → ARROWS → BOTH if movement doesn't respond
- **◐** hides the buttons
- In the app: **Back** = pause, **Back twice** = exit

## Option A — No install (Chrome on Android)
1. Open bookmarklet.txt, copy everything.
2. In Chrome, bookmark any page, edit it: name it `touch`, paste the text as the URL.
3. Open https://wow.aethus.pl/, tap the address bar, type `touch`,
   tap the bookmark (the one with the star). Controls appear. Repeat after each reload.

## Option B — Build the APK in the cloud (free, from your phone)
1. Create a new GitHub repository and upload everything in this folder
   (keep the `.github/workflows` folder — it's the build script).
2. Open the repo's **Actions** tab → the "Build APK" run starts automatically
   (or tap "Run workflow"). Takes ~3–5 minutes.
3. Open the finished run → download **AzerothTouch-apk** → unzip → install the APK
   (allow "install unknown apps" for your browser/files app when Android asks).

## Option C — Android Studio
Open this folder in Android Studio and press Run. To load a different game,
change `GAME_URL` in `MainActivity.java`.

## Notes
- The game needs **WebGPU**. Chrome on Android 12+ supports it on most recent phones.
  If the app shows a WebGPU warning but Chrome works, use Option A.
- Personal use only. This is an unofficial wrapper, not affiliated with Aethus or Blizzard.
